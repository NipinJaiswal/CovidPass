// import PropTypes from "prop-types";
import axios from 'axios';
import React, { Component } from 'react'

export default class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: ''
    }
  }
  changeHandler = (e) => {
    this.setState({
      [e.target.name]: e.target.value
    })
  }

  loginHandler = (e) => {
    e.preventDefault();
    console.log(this.state);
    axios.post('http://localhost:3002/login', this.state)
    .then((res)=>{
      console.log(res);
    }).catch((e)=>{
      console.log(e);
    })

  }

  render() {
    const { username, password } = this.state;
    return (
      <div className="conatiner">
        <div className="row">
          <form onSubmit={this.loginHandler} id="login">
            <div className="col  py-3 form-control form-control-sm">
              <label className="mx-3">username :</label>
              <input
                className="mx-3"
                type="text"
                autoComplete="off"
                required
                name="username" value={username} onChange={this.changeHandler}
                placeholder="username"
              />
            </div>
            <div className="col  py-3 form-control form-control-sm">
              <label className="mx-3">password :</label>
              <input
                className="mx-3"
                type="password"
                autoComplete="off"
                required
                name="password" value={password} onChange={this.changeHandler}
                placeholder="Password"
              />
            </div>
            <button type="submit" className="btn btn-dark">Login</button>
          </form>
        </div>
      </div>
    )
  }
}


