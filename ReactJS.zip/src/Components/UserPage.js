import React from 'react'

export default function UserPage() {
    return (
        <div className='container'>
            <div className="row  m-1">
                <div className="col form-floating m-2">
                    <input type="text" className="form-control" id="FirstName" placeholder="name@example.com" />
                    <label htmlFor="floatingInput">Source City</label>
                </div>
                <div className="col form-floating m-2">
                    <input type="password" className="form-control" id="floatingPassword" placeholder="Password" />
                    <label htmlFor="floatingPassword">Destination City</label>
                </div>
            </div>
            <div className="row  m-1">
                <div className="col  m-2">
                    <label htmlFor="floatingInput">Date of Traveling : </label>
                    <input type="datetime-local" className="lg" id="Test_DatetimeLocal" style={{ backgroundColor: 'rgb(142 252 255 / 20%)', width: '280px', height: '50px', border: '1px solid black' }} />
                </div>
                <div className="col  m-2">
                    <label htmlFor="floatingInput">Date of Return : </label>
                    <input type="datetime-local" className="lg" id="Test_DatetimeLocal" style={{ backgroundColor: 'rgb(142 252 255 / 20%)', width: '280px', height: '50px', border: '1px solid black' }} />
                </div>
            </div>

            <table className="table my-4">
                <thead>
                    <tr>
                        <td>Source</td>
                        <td>Destination</td>
                        <td>Travelling Date</td>
                        <td>Return Date</td>
                        <td>Status</td>
                    </tr>
                    
                </thead>
            </table>
        </div>
    )
}
