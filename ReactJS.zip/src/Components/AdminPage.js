import React from 'react'

export default function AdminPage() {
    return (
        <div className='container'>
            <table className="table my-4">
                <thead>
                    <tr>
                        <td>Source</td>
                        <td>Destination</td>
                        <td>Travelling Date</td>
                        <td>Return Date</td>
                        <td>Approve</td>
                        <td>Reject</td>
                    </tr>
                </thead>
                <tbody>

                </tbody>
            </table>

        </div>
    )
}
