import axios from 'axios'
import React, { Component } from 'react'

export default class Register extends Component {
  constructor() {
    super();
    this.state = {
      articles: [],
      loading: true,
      page: 1,
    }
  }

  componentDidMount() {
    // Simple POST request with a JSON body using fetch
    const requestOptions = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'test@gmail.com' })
    };
    fetch('http://localhost:3002/login', requestOptions)
      .then(response => response.json())
      .then(data => this.setState({ status: data.status }));
  }
  render() {
    return (
      <div className=" row conatiner">
        <form action="" id="login">
          <div className="col  py-3 form-control form-control-sm">
            <label className="mx-3">First Name :</label>
            <input required
              className="mx-3"
              type="text"
              autoComplete="off"
              required
              id="firstName"
              placeholder="First Name"
            />
          </div>
          <div className="col  py-3 form-control form-control-sm">
            <label className="mx-3">Last Name:</label>
            <input
              className="mx-3"
              type="text"
              autoComplete="off"
              id="lastname"
              placeholder="last name"
            />
          </div>
          <div className="col  py-3 form-control form-control-sm">
            <label className="mx-3">Email:</label>
            <input required
              className="mx-3"
              type="email"
              autoComplete="off"
              required
              id="email"
              placeholder="xyz@gmail.com"
            />
          </div>
          <div className="col  py-3 form-control form-control-sm">
            <label className="mx-3">password :</label>
            <input
              className="mx-3"
              type="password"
              autoComplete="off"
              required
              id="password"
              placeholder="Password"
            />
          </div>
          <div className="col  py-3 form-control form-control-sm">
            <input
              type="submit"
              className="mx-3 btn-primary btn-md"
              value="Register"
            />
          </div>
        </form>
      </div>
    )
  }
}
