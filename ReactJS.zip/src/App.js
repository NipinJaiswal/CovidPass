import logo from './logo.svg';
import './App.css';
import Navbar from './Components/Navbar';
import Login from './Components/Login';
import ReactDOM from "react-dom";
import Register from './Components/Register'
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import UserPage from './Components/UserPage';
import AdminPage from './Components/AdminPage';
function App() {
  return (
    <>
      <Router>
        <Navbar />
        <Routes>
          <Route exact path="/login" element={<Login />} />
          <Route exact path="/" element={<Register />} />
          <Route exact path="/userPage" element={<UserPage />} />
          <Route exact path="/adminPage" element={<AdminPage />} />
        </Routes>

      </Router>



    </>
  );
}

export default App;
