const express = require("express");
const app = express();
const mongoose = require("mongoose");
const path = require("path");
const port = 3002;
const url = "mongodb://localhost:27017/CovidPass";
const users = require("./model/registration");
const covidpass = require("./model/covidpass");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const secretKey = "asrrgfds489842dfes!#@!@#$#21scdfq83424fdtr324ty43fgewsadfg";
//Db connection
//Checking if Db is connected
const con = mongoose.connection;
mongoose.connect(url, { useNewUrlParser: true });
con.on("open", () => {
    console.log("Connected...!");
});

//data in json format
app.use(express.json());
app.use("/", express.static(path.join(__dirname, "static")));

//Routing
//UserRegistration
app.post('/',(req,res)=>{
    res.send('got the message');
})
app.post("/register", async (req, res) => {
    const { email, password: p, firstName, lastName } = req.body;
    console.log(req.body);
    const role = "user";
    const password = await bcrypt.hash(p, 10);
    try {
        await users.create({
            email,
            firstName,
            lastName,
            role,
            password,
        });
        res.send({ status: "ok" });
    } catch (error) {
        console.log(error);
        if (error.code == 11000) {
            res.send({ status: "error", error: "email already registered" });
        } else {
            res.send({ status: "error", error: "invalid details provided" });
        }
    }
});
//UserLogin
//Routing
app.post("/login", async (req, res) => {
    const { email, password } = req.body;
    console.log(req.body);
    const user = await users.findOne({ email }).lean();
    if(user){
    if (await bcrypt.compare(password, user.password)) {
        const token = jwt.sign(
            {
                id: user._id,
                email: user.email,
            },
            secretKey
        );
        res.json({ status: "ok", data: token });
    }
}else{
    res.json({ status: "error", error: 'Invalid details provided' });
}
});
//Covid Pass Application
app.post("/covidPassApplication", async (req, res) => {
    const { token, email, sourceCity, destinationCity, travelDate, returnDate } =
        req.body;

    const status = "Applied";
    const covidPass = await covidpass.findOne({ email, status }).lean();
    if (covidPass) {
        res.send({ status: "error", error: "already applied" });
    } else {
        const isLoggedIn = await validateUser(token,email);
        if (isLoggedIn) {
            try {
                await covidpass.deleteOne({ email });
                await covidpass.create({
                    email,
                    sourceCity,
                    destinationCity,
                    travelDate,
                    returnDate,
                    status,
                });
                res.send({ status: "ok" });
            } catch (error) {
                if (error.code == 11000) {
                    console.log(error);
                    res.send({ status: "error", error: "email already registered" });
                } else {
                    console.log(error);
                    res.send({ status: "error", error: "invalid details provided" });
                }
            }
        } else {
            res.send({ status: "error", error: "please Login" });
        }
    }
});
//Pass Apllication
app.post("/covidPassApproval", async (req, res) => {
    const { token, useremail, status } = req.body;
    const isAdmin = await validateAdmin(token);
    console.log(isAdmin);
    if (isAdmin) {
        try {
            await covidpass.updateOne({ email: useremail, status: status });
            res.send({ status: "ok" });
        } catch (error) {
            res.send({ status: "error", error: "invalid details provided" });
        }
    } else {
        res.send({ status: "error", error: "you don't have permissions" });
    }
});
//GetAllApplications
app.post("/getAllApplications",async(req,res)=>{
 const {token,email} = req.body;
 const isValidAdmin= await validateAdmin(token);
 console.log(token, isValidAdmin);
 if(isValidAdmin){
     try{
         const applications=await covidpass.find({});
         res.send({status:'ok',data:applications});
     }catch(error){
         console.log(error);
         res.send({status:'error',error:'Invalid details are provided'});
     }

 }else{
     res.send({status:'error',error:'You do not have permissions'});
 }
})
//functions
async function validateUser(token,email) {
    const user = jwt.verify(token, secretKey);
    console.log(user.email, email);
    if (user.email==email) {
        return true;
    }
    return false;
}
async function validateAdmin(token) {
    try {
        const user = jwt.verify(token, secretKey);
        const { email } = user
        const userDetails = await users.findOne({ email }).lean();
        if (userDetails.role === 'Admin') {
            console.log(user.role);
            return true;
        }
        return false;

    } catch (error) {
        return false;
    }

}

//Server port
app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`);
});
